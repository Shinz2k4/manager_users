<!-- Những làm liên quan đến session và coockies -->
<?php
if(!defined('_CODE')) {
    die('Access denied...');
}