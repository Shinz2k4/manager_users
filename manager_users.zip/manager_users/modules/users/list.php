
<?php
if(!defined('_CODE')) {
    die('Access denied...');
}
?>
<h1>List trong users</h1>