<?php
if(!defined('_CODE')) {
    die('Access denied...');
    
}
require_once _WEB_PATH_TEMPLATES.'/layout/header.php';
?>

<?php
require_once _WEB_PATH_TEMPLATES.'/layout/footer.php';
?>
