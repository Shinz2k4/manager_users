<?php
if(!defined('_CODE')) {
    die('Access denied...');
}