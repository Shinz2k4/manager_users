<?php
if(!defined('_CODE')) {
    die('Access denied...');
}
?>
<h1>ERROR 404</h1>
