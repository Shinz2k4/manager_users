<?php
if(!defined('_CODE')) {
    die('Access denied...');
}?>

<script src="<?php echo _WEB_HOST_TEMPLATES; ?>/js/bootstrap.min.js"></script>
<script src="<?php echo _WEB_HOST_TEMPLATES; ?>/js/custom.js"></script>
